@echo off
setlocal

cd /d "%~dp0"

:: ============================================
:: ACT CORP AUDIT SYSTEM INSTALLER
:: ============================================

:: Create Folder
if not exist "C:\ACT_Audit" mkdir "C:\ACT_Audit"

:: Remove Old Tasks
schtasks /delete /tn "ACT_Monthly_Audit" /f >nul 2>&1
schtasks /delete /tn "ACT_Weekly_Audit" /f >nul 2>&1

:: Copy MSI
copy /y "ACT_Audit.msi" "C:\ACT_Audit\ACT_Audit.msi" >nul

:: Silent Install MSI
msiexec /i "C:\ACT_Audit\ACT_Audit.msi" /qn /norestart

:: Create Weekly Task
schtasks /create ^
/tn "ACT_Weekly_Audit" ^
/tr "C:\Program Files\ACT_Audit\ACT_Audit.exe" ^
/sc weekly ^
/d MON ^
/st 10:00 ^
/rl highest ^
/f

:: Enable Run When Missed
powershell -ExecutionPolicy Bypass -Command "Set-ScheduledTask -TaskName 'ACT_Weekly_Audit' -Settings (New-ScheduledTaskSettingsSet -StartWhenAvailable)" >nul 2>&1

:: Initial Silent Run
start /min "" "C:\Program Files\ACT_Audit\ACT_Audit.exe"

exit