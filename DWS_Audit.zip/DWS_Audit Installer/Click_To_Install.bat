@echo off
setlocal
title ACT Corp Audit - Weekly Installer
cd /d "%~dp0"

echo ----------------------------------------------------
echo         ACT CORP AUDIT SYSTEM INSTALLER
echo           (Weekly Sync Configuration)
echo ----------------------------------------------------

:: 1. Create/Verify folder
if not exist "C:\ACT_Audit" mkdir "C:\ACT_Audit"

:: 2. Cleanup old Task and Copy Engine
schtasks /delete /tn "ACT_Monthly_Audit" /f >nul 2>&1
schtasks /delete /tn "ACT_Weekly_Audit" /f >nul 2>&1
echo Copying Audit Engine...
copy /y "ACT_Audit.msi" "C:\ACT_Audit\ACT_Audit.msi"

:: 3. Create NEW Weekly Task (Runs Mondays at 10 AM)
echo Registering Weekly Scheduled Task...
schtasks /create /tn "ACT_Weekly_Audit" /tr "C:\ACT_Audit\ACT_Audit.msi" /sc weekly /d MON /st 10:00 /rl highest /f

:: 4. Ensure it runs even if missed (Laptop turned off)
powershell -ExecutionPolicy Bypass -Command "Set-ScheduledTask -TaskName 'ACT_Weekly_Audit' -Settings (New-ScheduledTaskSettingsSet -StartWhenAvailable)"

:: 5. Initial Run
echo Triggering initial scan...
start "" "C:\ACT_Audit\ACT_Audit.msi"

echo ----------------------------------------------------
echo ✅ SUCCESS: Weekly Sync Configured.
echo ----------------------------------------------------
timeout /t 5